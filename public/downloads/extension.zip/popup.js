const API_BASE = 'https://agiesai-sentinel-unified.onrender.com';

function computePopupStatus({ credential, connectionStatus, employeeName }) {
  if (!credential) {
    if (connectionStatus === 'REVOKED') {
      return {
        cardClass: 'status disconnected',
        text: 'Disconnected — Revoked',
        pairingNotice: 'Extension credential revoked by administrator. Please pair again.',
      };
    }
    return {
      cardClass: 'status disconnected',
      text: 'Unpaired — Disconnected',
      pairingNotice: 'Pairing required to activate protection.',
    };
  }

  if (connectionStatus === 'DISABLED') {
    return {
      cardClass: 'status disabled',
      text: 'Access Disabled by Admin',
      pairingNotice: null,
    };
  }

  return {
    cardClass: 'status',
    text: employeeName ? `Protection Active (${employeeName})` : 'Protection Active',
    pairingNotice: null,
  };
}

function computeIdentityDisplay({ credential, employeeId, employeeName, connectionStatus }) {
  if (!credential) {
    if (connectionStatus === 'REVOKED') {
      const label = employeeName && employeeId ? `${employeeName} • ${employeeId} (Revoked)` : 'Credential Revoked';
      return {
        optionValue: '',
        optionText: label,
        statusText: 'Credential revoked by administrator. Please pair again.',
        disabled: true,
      };
    }
    return {
      optionValue: '',
      optionText: 'No employee identity linked',
      statusText: 'Pair extension using a code from the admin dashboard.',
      disabled: true,
    };
  }

  const label = employeeName && employeeId
    ? `${employeeName} • ${employeeId}`
    : (employeeName || employeeId || 'Employee Identity');

  if (connectionStatus === 'DISABLED') {
    return {
      optionValue: employeeId || '',
      optionText: label,
      statusText: 'Extension access disabled by administrator.',
      disabled: true,
    };
  }

  return {
    optionValue: employeeId || '',
    optionText: label,
    statusText: employeeId ? `Active protection bound to ${employeeId}.` : 'Active protection bound to employee.',
    disabled: true,
  };
}

async function updateConnectionStatus() {
  const card = document.getElementById('connectionStatusCard');
  const text = document.getElementById('connectionStatusText');
  const pairingStatus = document.getElementById('pairingStatus');

  if (!card || !text) return;

  const data = await chrome.storage.local.get({
    credential: null,
    connectionStatus: null,
    employeeName: '',
    employeeId: '',
  });

  const status = computePopupStatus(data);
  card.className = status.cardClass;
  text.textContent = status.text;

  if (status.pairingNotice && pairingStatus && !pairingStatus.textContent) {
    pairingStatus.textContent = status.pairingNotice;
    pairingStatus.className = data.connectionStatus === 'REVOKED' ? 'pairing-status error' : 'pairing-status';
  }
}

async function renderIdentity() {
  const select = document.getElementById('employeeSelect');
  const status = document.getElementById('identityStatus');
  if (!select || !status) return;

  const data = await chrome.storage.local.get({
    credential: null,
    employeeId: '',
    employeeName: '',
    connectionStatus: null,
  });

  const display = computeIdentityDisplay(data);

  select.innerHTML = '';
  const option = document.createElement('option');
  option.value = display.optionValue;
  option.textContent = display.optionText;
  select.appendChild(option);
  select.disabled = display.disabled;

  status.textContent = display.statusText;
}

// Alias for backwards compatibility
const loadEmployees = renderIdentity;

async function loadLastResult() {
  const data = await chrome.storage.local.get('lastResult');
  const last = data.lastResult;
  if (!last) return;

  const decision = last.policy?.decision || 'UNKNOWN';
  const score = last.risk?.score;
  const time = last.checkedAt ? new Date(last.checkedAt).toLocaleTimeString() : '';
  const employee = last.employee_name ? ` • ${last.employee_name}` : '';

  document.getElementById('decision').textContent = `${decision}${score != null ? ` • Risk ${score}/100` : ''}`;
  document.getElementById('details').textContent = `${last.policy?.message || 'Security decision received.'}${employee}${time ? ` Checked ${time}.` : ''}`;
}

async function load() {
  setupPairing();
  await updateConnectionStatus();
  await renderIdentity();
  await loadLastResult();

  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        updateConnectionStatus();
        renderIdentity();
      }
    });
  }
}

function setupPairing() {
  const input = document.getElementById('pairingCodeInput');
  const button = document.getElementById('pairBtn');
  const status = document.getElementById('pairingStatus');

  if (!button || !input || !status) return;

  async function handlePair() {
    if (button.disabled) {
      return;
    }

    const code = input.value.trim();
    if (!code) {
      status.textContent = 'Please enter a pairing code.';
      status.className = 'pairing-status error';
      return;
    }

    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = 'Pairing…';
    status.textContent = 'Pairing extension…';
    status.className = 'pairing-status';

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'AGIES_PAIR_EXTENSION',
        code,
      });

      if (response && response.ok) {
        const name = response.employeeName || 'Employee';
        const id = response.employeeId || '';
        status.textContent = `Paired successfully: ${name} (${id})`;
        status.className = 'pairing-status success';
        input.value = '';
        await updateConnectionStatus();
        await renderIdentity();
      } else {
        const errorMsg = response?.error || 'Pairing failed. Please check the code and try again.';
        status.textContent = errorMsg;
        status.className = 'pairing-status error';
        await updateConnectionStatus();
        await renderIdentity();
      }
    } catch (err) {
      status.textContent = err?.message || 'Error communicating with background worker.';
      status.className = 'pairing-status error';
      await updateConnectionStatus();
      await renderIdentity();
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  }

  button.addEventListener('click', handlePair);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      handlePair();
    }
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    API_BASE,
    computePopupStatus,
    computeIdentityDisplay,
    updateConnectionStatus,
    renderIdentity,
    loadEmployees,
    load,
  };
}

if (typeof document !== 'undefined') {
  load();
}

