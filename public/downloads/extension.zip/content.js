(() => {
  'use strict';

  const STATE = {
    busy: false,
    isProgrammaticSubmitting: false,
    approvedToken: null, // { text: string, timer: any, createdAt: number }
  };

  const API_MESSAGE = 'AGIES_ANALYZE';

  const LOCAL_RULES = [
    {
      type: 'API_KEY',
      regex: /\b(?:sk-(?:live|prod|test)-[A-Za-z0-9_-]{12,}|AKIA[0-9A-Z]{16})\b/i
    },
    {
      type: 'EMAIL',
      regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i
    },
    {
      type: 'CREDIT_CARD',
      regex: /\b(?:\d[ -]*?){13,19}\b/
    },
    {
      type: 'JWT',
      regex: /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/
    },
    {
      type: 'PRIVATE_KEY',
      regex: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/i
    },
    {
      type: 'PASSWORD',
      regex: /\b(?:password|passwd|pwd)\s*[:=]\s*[^\s]{6,}/i
    },
    {
      type: 'DATABASE_URL',
      regex: /\b(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql):\/\/[^\s]+/i
    },
  ];

  function visible(el) {
    if (!el) return false;

    if (
      typeof window === 'undefined' ||
      typeof window.getComputedStyle !== 'function'
    ) {
      return true;
    }

    const style = window.getComputedStyle(el);
    const rect =
      typeof el.getBoundingClientRect === 'function'
        ? el.getBoundingClientRect()
        : { width: 100, height: 100 };

    return (
      style.display !== 'none' &&
      style.visibility !== 'hidden' &&
      rect.width > 0 &&
      rect.height > 0
    );
  }

  function elementFromEvent(event) {
    if (!event) return null;

    const path =
      typeof event.composedPath === 'function'
        ? event.composedPath()
        : [];

    return (
      path.find((item) => item instanceof Element) ||
      (event.target instanceof Element ? event.target : null)
    );
  }

  /*
   * =========================================================================
   * Platform Adapter Interface & ChatGPT Adapter
   * =========================================================================
   *
   * Adapter contract:
   * - name: string (canonical platform identifier, e.g. 'ChatGPT')
   * - hostnames: string[] (explicit allowed primary hostnames)
   * - matches(hostname: string): boolean
   * - findEditor(): Element | null
   * - readText(editor: Element | null): string
   * - findSubmitButton(editor: Element | null): Element | null
   * - isSendButton(button: Element | null): boolean
   * - isSubmitKey(event: KeyboardEvent, editor: Element | null): boolean
   * - submitAfterDecision(editor: Element | null): boolean
   */

  const ChatGPTAdapter = {
    name: 'ChatGPT',
    hostnames: ['chatgpt.com', 'chat.openai.com'],

    matches(hostname) {
      if (typeof hostname !== 'string') return false;
      const host = hostname.toLowerCase().trim();
      return (
        host === 'chatgpt.com' ||
        host.endsWith('.chatgpt.com') ||
        host === 'chat.openai.com' ||
        host.endsWith('.chat.openai.com')
      );
    },

    findEditor() {
      if (typeof document === 'undefined') return null;

      const candidates = [
        ...document.querySelectorAll('[data-testid="text-input"]'),
        ...document.querySelectorAll('#prompt-textarea'),
        ...document.querySelectorAll('textarea'),
        ...document.querySelectorAll('[contenteditable="true"]'),
        ...document.querySelectorAll('.ProseMirror'),
      ];

      return (
        candidates
          .filter(visible)
          .sort((a, b) => {
            const score = (el) => {
              if (el.matches('[data-testid="text-input"]')) return 5;
              if (el.id === 'prompt-textarea') return 4;
              if (el.matches('[contenteditable="true"]')) return 3;
              if (el.matches('textarea')) return 2;
              return 1;
            };

            return score(b) - score(a);
          })[0] || null
      );
    },

    readText(editor) {
      if (!editor) return '';

      if (
        (typeof HTMLTextAreaElement !== 'undefined' &&
          editor instanceof HTMLTextAreaElement) ||
        (typeof HTMLInputElement !== 'undefined' &&
          editor instanceof HTMLInputElement) ||
        editor.tagName === 'TEXTAREA' ||
        editor.tagName === 'INPUT'
      ) {
        return editor.value || '';
      }

      return (editor.innerText || editor.textContent || '').trim();
    },

    buttonLabel(button) {
      return [
        button?.getAttribute?.('aria-label'),
        button?.getAttribute?.('data-testid'),
        button?.getAttribute?.('data-state'),
        button?.textContent,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
    },

    isSendButton(button) {
      if (!button) return false;
      if (typeof Element !== 'undefined' && !(button instanceof Element)) {
        return false;
      }
      if (button.tagName !== 'BUTTON') return false;

      if (
        button.disabled ||
        button.getAttribute?.('aria-disabled') === 'true'
      ) {
        return false;
      }

      const label = this.buttonLabel(button);

      return /send|submit|prompt|message-submit/.test(label);
    },

    findSubmitButton(editor) {
      const form = editor?.closest?.('form');

      if (form) {
        const buttons = [...form.querySelectorAll('button')];

        const submit = buttons.find(
          (button) =>
            !button.disabled &&
            (button.type === 'submit' || this.isSendButton(button))
        );

        if (submit) return submit;
      }

      if (typeof document === 'undefined') return null;

      return (
        [...document.querySelectorAll('button')].find((button) =>
          this.isSendButton(button)
        ) || null
      );
    },

    isSubmitKey(event, editor) {
      if (
        !event ||
        event.key !== 'Enter' ||
        event.shiftKey ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey
      ) {
        return false;
      }

      const target = elementFromEvent(event);

      return Boolean(
        editor &&
          (target === editor ||
            (typeof editor.contains === 'function' && editor.contains(target)))
      );
    },

    submitAfterDecision(editor) {
      const button = this.findSubmitButton(editor);

      if (button && typeof button.click === 'function') {
        button.click();
        return true;
      }

      const form = editor?.closest?.('form');

      if (form?.requestSubmit) {
        form.requestSubmit();
        return true;
      }

      return false;
    },
  };

  /*
   * Gemini Platform Adapter
   * Target site: https://gemini.google.com/
   */
  const GeminiAdapter = {
    name: 'Gemini',
    hostnames: ['gemini.google.com'],

    matches(hostname) {
      if (typeof hostname !== 'string') return false;
      const cleanHost = hostname.split(':')[0].toLowerCase().trim();
      return (
        cleanHost === 'gemini.google.com' ||
        cleanHost.endsWith('.gemini.google.com')
      );
    },

    findEditor() {
      if (typeof document === 'undefined') return null;

      const candidates = [
        ...document.querySelectorAll('rich-textarea .ql-editor'),
        ...document.querySelectorAll('.ql-editor[contenteditable="true"]'),
        ...document.querySelectorAll('rich-textarea [contenteditable="true"]'),
        ...document.querySelectorAll('div[contenteditable="true"][role="textbox"]'),
        ...document.querySelectorAll('[aria-label*="prompt" i][contenteditable="true"]'),
        ...document.querySelectorAll('[aria-label*="Enter a prompt" i]'),
        ...document.querySelectorAll('textarea'),
        ...document.querySelectorAll('[contenteditable="true"]'),
      ];

      return (
        candidates
          .filter(visible)
          .sort((a, b) => {
            const score = (el) => {
              if (el.matches('rich-textarea .ql-editor')) return 6;
              if (el.matches('.ql-editor[contenteditable="true"]')) return 5;
              if (el.matches('div[contenteditable="true"][role="textbox"]')) return 4;
              if (el.matches('[aria-label*="prompt" i]')) return 3;
              if (el.matches('[contenteditable="true"]')) return 2;
              if (el.matches('textarea')) return 1;
              return 0;
            };

            return score(b) - score(a);
          })[0] || null
      );
    },

    readText(editor) {
      if (!editor) return '';

      if (
        (typeof HTMLTextAreaElement !== 'undefined' &&
          editor instanceof HTMLTextAreaElement) ||
        (typeof HTMLInputElement !== 'undefined' &&
          editor instanceof HTMLInputElement) ||
        editor.tagName === 'TEXTAREA' ||
        editor.tagName === 'INPUT'
      ) {
        return editor.value || '';
      }

      return (editor.innerText || editor.textContent || '').trim();
    },

    buttonLabel(button) {
      return [
        button?.getAttribute?.('aria-label'),
        button?.getAttribute?.('data-test-id'),
        button?.getAttribute?.('data-testid'),
        button?.getAttribute?.('mattooltip'),
        button?.getAttribute?.('title'),
        button?.textContent,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
    },

    isSendButton(button) {
      if (!button) return false;
      if (typeof Element !== 'undefined' && !(button instanceof Element)) {
        return false;
      }
      if (
        button.tagName !== 'BUTTON' &&
        button.getAttribute?.('role') !== 'button'
      ) {
        return false;
      }

      if (
        button.disabled ||
        button.getAttribute?.('aria-disabled') === 'true'
      ) {
        return false;
      }

      const label = this.buttonLabel(button);

      return /send|submit|prompt|send message/.test(label);
    },

    findSubmitButton(editor) {
      const container =
        editor?.closest?.('rich-textarea') ||
        editor?.closest?.('.input-area') ||
        editor?.closest?.('form') ||
        editor?.parentElement;

      if (container) {
        const buttons = [
          ...container.querySelectorAll('button'),
          ...container.querySelectorAll('[role="button"]'),
        ];

        const submit = buttons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        );

        if (submit) return submit;
      }

      if (typeof document === 'undefined') return null;

      const docButtons = [
        ...document.querySelectorAll('button.send-button'),
        ...document.querySelectorAll('button[aria-label*="Send" i]'),
        ...document.querySelectorAll('[role="button"][aria-label*="Send" i]'),
        ...document.querySelectorAll('button'),
      ];

      return (
        docButtons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        ) || null
      );
    },

    isSubmitKey(event, editor) {
      if (
        !event ||
        event.key !== 'Enter' ||
        event.shiftKey ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey
      ) {
        return false;
      }

      const target = elementFromEvent(event);

      return Boolean(
        editor &&
          (target === editor ||
            (typeof editor.contains === 'function' && editor.contains(target)))
      );
    },

    submitAfterDecision(editor) {
      const button = this.findSubmitButton(editor);

      if (button && typeof button.click === 'function') {
        button.click();
        return true;
      }

      const form = editor?.closest?.('form');

      if (form?.requestSubmit) {
        form.requestSubmit();
        return true;
      }

      return false;
    },
  };

  /*
   * Claude Platform Adapter
   * Target site: https://claude.ai/
   */
  const ClaudeAdapter = {
    name: 'Claude',
    hostnames: ['claude.ai'],

    matches(hostname) {
      if (typeof hostname !== 'string') return false;
      const cleanHost = hostname.split(':')[0].toLowerCase().trim();
      return (
        cleanHost === 'claude.ai' ||
        cleanHost.endsWith('.claude.ai')
      );
    },

    findEditor() {
      if (typeof document === 'undefined') return null;

      const candidates = [
        ...document.querySelectorAll('.ProseMirror[contenteditable="true"]'),
        ...document.querySelectorAll('fieldset [contenteditable="true"]'),
        ...document.querySelectorAll('[contenteditable="true"][data-placeholder]'),
        ...document.querySelectorAll('.ProseMirror'),
        ...document.querySelectorAll('div[contenteditable="true"][role="textbox"]'),
        ...document.querySelectorAll('div[contenteditable="true"]'),
        ...document.querySelectorAll('textarea'),
        ...document.querySelectorAll('[contenteditable="true"]'),
      ];

      return (
        candidates
          .filter(visible)
          .sort((a, b) => {
            const score = (el) => {
              if (el.matches('.ProseMirror[contenteditable="true"]')) return 6;
              if (el.matches('fieldset [contenteditable="true"]')) return 5;
              if (el.matches('[contenteditable="true"][data-placeholder]')) return 4;
              if (el.matches('.ProseMirror')) return 3;
              if (el.matches('div[contenteditable="true"][role="textbox"]')) return 2;
              if (el.matches('textarea')) return 1;
              return 0;
            };

            return score(b) - score(a);
          })[0] || null
      );
    },

    readText(editor) {
      if (!editor) return '';

      if (
        (typeof HTMLTextAreaElement !== 'undefined' &&
          editor instanceof HTMLTextAreaElement) ||
        (typeof HTMLInputElement !== 'undefined' &&
          editor instanceof HTMLInputElement) ||
        editor.tagName === 'TEXTAREA' ||
        editor.tagName === 'INPUT'
      ) {
        return editor.value || '';
      }

      return (editor.innerText || editor.textContent || '').trim();
    },

    buttonLabel(button) {
      return [
        button?.getAttribute?.('aria-label'),
        button?.getAttribute?.('data-testid'),
        button?.getAttribute?.('title'),
        button?.textContent,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
    },

    isSendButton(button) {
      if (!button) return false;
      if (typeof Element !== 'undefined' && !(button instanceof Element)) {
        return false;
      }
      if (
        button.tagName !== 'BUTTON' &&
        button.getAttribute?.('role') !== 'button'
      ) {
        return false;
      }

      if (
        button.disabled ||
        button.getAttribute?.('aria-disabled') === 'true'
      ) {
        return false;
      }

      const label = this.buttonLabel(button);

      return /send|submit/i.test(label);
    },

    findSubmitButton(editor) {
      const container =
        editor?.closest?.('fieldset') ||
        editor?.closest?.('form') ||
        editor?.closest?.('[class*="input"]') ||
        editor?.parentElement;

      if (container) {
        const buttons = [
          ...container.querySelectorAll('button'),
          ...container.querySelectorAll('[role="button"]'),
        ];

        const submit = buttons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        );

        if (submit) return submit;
      }

      if (typeof document === 'undefined') return null;

      const docButtons = [
        ...document.querySelectorAll('button[aria-label*="Send" i]'),
        ...document.querySelectorAll('button[data-testid*="send" i]'),
        ...document.querySelectorAll('[role="button"][aria-label*="Send" i]'),
        ...document.querySelectorAll('button'),
      ];

      return (
        docButtons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        ) || null
      );
    },

    isSubmitKey(event, editor) {
      if (
        !event ||
        event.key !== 'Enter' ||
        event.shiftKey ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey
      ) {
        return false;
      }

      const target = elementFromEvent(event);

      return Boolean(
        editor &&
          (target === editor ||
            (typeof editor.contains === 'function' && editor.contains(target)))
      );
    },

    submitAfterDecision(editor) {
      const button = this.findSubmitButton(editor);

      if (button && typeof button.click === 'function') {
        button.click();
        return true;
      }

      const form = editor?.closest?.('form');

      if (form?.requestSubmit) {
        form.requestSubmit();
        return true;
      }

      return false;
    },
  };

  /*
   * Perplexity Platform Adapter
   * Target site: https://www.perplexity.ai/
   */
  const PerplexityAdapter = {
    name: 'Perplexity',
    hostnames: ['perplexity.ai', 'www.perplexity.ai'],

    matches(hostname) {
      if (typeof hostname !== 'string') return false;
      const cleanHost = hostname.split(':')[0].toLowerCase().trim();
      return (
        cleanHost === 'perplexity.ai' ||
        cleanHost.endsWith('.perplexity.ai')
      );
    },

    findEditor() {
      if (typeof document === 'undefined') return null;

      const candidates = [
        ...document.querySelectorAll('textarea[placeholder*="Ask" i]'),
        ...document.querySelectorAll('textarea[placeholder*="search" i]'),
        ...document.querySelectorAll('textarea[placeholder*="anything" i]'),
        ...document.querySelectorAll('textarea'),
        ...document.querySelectorAll('[contenteditable="true"][role="textbox"]'),
        ...document.querySelectorAll('div[contenteditable="true"]'),
        ...document.querySelectorAll('[contenteditable="true"]'),
      ];

      return (
        candidates
          .filter(visible)
          .sort((a, b) => {
            const score = (el) => {
              if (el.matches('textarea[placeholder*="Ask" i]')) return 6;
              if (el.matches('textarea[placeholder*="search" i]')) return 5;
              if (el.matches('textarea[placeholder*="anything" i]')) return 4;
              if (el.matches('textarea')) return 3;
              if (el.matches('[contenteditable="true"][role="textbox"]')) return 2;
              if (el.matches('[contenteditable="true"]')) return 1;
              return 0;
            };

            return score(b) - score(a);
          })[0] || null
      );
    },

    readText(editor) {
      if (!editor) return '';

      if (
        (typeof HTMLTextAreaElement !== 'undefined' &&
          editor instanceof HTMLTextAreaElement) ||
        (typeof HTMLInputElement !== 'undefined' &&
          editor instanceof HTMLInputElement) ||
        editor.tagName === 'TEXTAREA' ||
        editor.tagName === 'INPUT'
      ) {
        return editor.value || '';
      }

      return (editor.innerText || editor.textContent || '').trim();
    },

    buttonLabel(button) {
      return [
        button?.getAttribute?.('aria-label'),
        button?.getAttribute?.('data-testid'),
        button?.getAttribute?.('title'),
        button?.getAttribute?.('type'),
        button?.textContent,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
    },

    isSendButton(button) {
      if (!button) return false;
      if (typeof Element !== 'undefined' && !(button instanceof Element)) {
        return false;
      }
      if (
        button.tagName !== 'BUTTON' &&
        button.getAttribute?.('role') !== 'button'
      ) {
        return false;
      }

      if (
        button.disabled ||
        button.getAttribute?.('aria-disabled') === 'true'
      ) {
        return false;
      }

      const label = this.buttonLabel(button);

      // Avoid ancillary controls: attach, file, focus mode, copy, share
      if (/attach|focus|file|upload|copy|share/i.test(label)) {
        return false;
      }

      return /submit|search|send|ask/i.test(label) || button.getAttribute?.('type') === 'submit';
    },

    findSubmitButton(editor) {
      const container =
        editor?.closest?.('form') ||
        editor?.closest?.('[class*="input"]') ||
        editor?.closest?.('[class*="search"]') ||
        editor?.parentElement;

      if (container) {
        const buttons = [
          ...container.querySelectorAll('button'),
          ...container.querySelectorAll('[role="button"]'),
        ];

        const submit = buttons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        );

        if (submit) return submit;
      }

      if (typeof document === 'undefined') return null;

      const docButtons = [
        ...document.querySelectorAll('button[aria-label*="Submit" i]'),
        ...document.querySelectorAll('button[aria-label*="Search" i]'),
        ...document.querySelectorAll('button[aria-label*="Ask" i]'),
        ...document.querySelectorAll('button[aria-label*="Send" i]'),
        ...document.querySelectorAll('button[type="submit"]'),
        ...document.querySelectorAll('[role="button"][aria-label*="Submit" i]'),
        ...document.querySelectorAll('button'),
      ];

      return (
        docButtons.find(
          (button) =>
            !button.disabled &&
            button.getAttribute?.('aria-disabled') !== 'true' &&
            this.isSendButton(button)
        ) || null
      );
    },

    isSubmitKey(event, editor) {
      if (
        !event ||
        event.key !== 'Enter' ||
        event.shiftKey ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey
      ) {
        return false;
      }

      const target = elementFromEvent(event);

      return Boolean(
        editor &&
          (target === editor ||
            (typeof editor.contains === 'function' && editor.contains(target)))
      );
    },

    submitAfterDecision(editor) {
      const button = this.findSubmitButton(editor);

      if (button && typeof button.click === 'function') {
        button.click();
        return true;
      }

      const form = editor?.closest?.('form');

      if (form?.requestSubmit) {
        form.requestSubmit();
        return true;
      }

      return false;
    },
  };

  /*
   * Explicit adapter registry: registers ChatGPTAdapter, GeminiAdapter, ClaudeAdapter, and PerplexityAdapter.
   */
  const ADAPTER_REGISTRY = [
    ChatGPTAdapter,
    GeminiAdapter,
    ClaudeAdapter,
    PerplexityAdapter,
  ];

  function resolvePlatformAdapter(hostname) {
    if (typeof hostname !== 'string') return null;

    // Strip optional port if passed e.g. hostname:port
    const cleanHost = hostname.split(':')[0].toLowerCase().trim();
    if (!cleanHost) return null;

    for (const adapter of ADAPTER_REGISTRY) {
      if (
        typeof adapter?.matches === 'function' &&
        adapter.matches(cleanHost)
      ) {
        return adapter;
      }
    }

    return null;
  }

  // Active adapter resolved once at startup
  let activeAdapter = null;
  if (typeof window !== 'undefined' && window.location) {
    activeAdapter = resolvePlatformAdapter(window.location.hostname || '');
  }

  // Shared backward-compatible helpers
  function findEditor() {
    return (activeAdapter || ChatGPTAdapter).findEditor();
  }

  function readText(editor) {
    return (activeAdapter || ChatGPTAdapter).readText(editor);
  }

  function isSendButton(button) {
    return (activeAdapter || ChatGPTAdapter).isSendButton(button);
  }

  function findSubmitButton(editor) {
    return (activeAdapter || ChatGPTAdapter).findSubmitButton(editor);
  }

  function localScan(text) {
    return LOCAL_RULES.filter((rule) => rule.regex.test(text)).map(
      (rule) => rule.type
    );
  }

  function showNotice(kind, title, message, actions = []) {
    if (typeof document === 'undefined') return;

    document.getElementById('agies-sentinel-notice')?.remove();

    const border =
      kind === 'BLOCK'
        ? '#ef4444'
        : kind === 'WARN'
          ? '#f59e0b'
          : '#22c55e';

    const box = document.createElement('div');
    box.id = 'agies-sentinel-notice';

    box.style.cssText = [
      'position:fixed',
      'right:24px',
      'bottom:24px',
      'z-index:2147483647',
      'width:390px',
      'padding:16px',
      'border-radius:14px',
      'background:#0b1220',
      'color:#e5edf7',
      'font-family:Inter,Arial,sans-serif',
      'box-shadow:0 14px 45px rgba(0,0,0,.45)',
      `border:1px solid ${border}`,
    ].join(';');

    const heading = document.createElement('div');
    heading.style.cssText = 'font-size:14px;font-weight:700;margin-bottom:6px';
    heading.textContent = `AgiesAI Sentinel — ${title}`;

    const body = document.createElement('div');
    body.style.cssText = 'font-size:12px;line-height:1.5;color:#a9b6c8';
    body.textContent = message;

    const footer = document.createElement('div');
    footer.style.cssText = 'display:flex;gap:8px;margin-top:12px';

    for (const action of actions) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = action.label;

      button.style.cssText = [
        'border:0',
        'border-radius:8px',
        'padding:8px 12px',
        'cursor:pointer',
        'background:#162235',
        'color:#e5edf7',
        'font-weight:600',
        'font-size:12px',
      ].join(';');

      button.addEventListener('click', async () => {
        box.remove();

        try {
          await action.onClick();
        } catch (error) {
          console.error('[AgiesAI Sentinel] Action error:', error);
        }
      });

      footer.appendChild(button);
    }

    box.append(heading, body, footer);
    document.documentElement.appendChild(box);

    if (!actions.length) {
      setTimeout(() => box.remove(), 5500);
    }
  }

  /*
   * =========================================================================
   * Hardened Resubmission Token Management
   * =========================================================================
   */

  function clearApproval() {
    if (STATE.approvedToken?.timer) {
      clearTimeout(STATE.approvedToken.timer);
    }
    STATE.approvedToken = null;
  }

  function armApprovedSubmit(text) {
    clearApproval();

    if (typeof text !== 'string' || !text) {
      return;
    }

    const timer = setTimeout(() => {
      clearApproval();
    }, 3000);

    STATE.approvedToken = {
      text,
      timer,
      createdAt: Date.now(),
    };
  }

  function consumeAllowedSubmit(currentText) {
    const token = STATE.approvedToken;
    if (!token) {
      return false;
    }

    // Always clear approval immediately on first evaluation (strictly single-use)
    clearApproval();

    // Verify current editor text matches the exact approved prompt text
    if (typeof currentText !== 'string' || currentText !== token.text) {
      console.warn(
        '[AgiesAI Sentinel] Submission text does not match approved text. Expiring approval and intercepting.'
      );
      return false;
    }

    return true;
  }

  async function recordIncidentAction(incidentId, action) {
    if (!incidentId) return;

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'AGIES_RECORD_ACTION',
        incidentId,
        action,
      });

      if (!response?.ok) {
        console.warn(
          '[AgiesAI Sentinel] Could not record incident action:',
          response?.error
        );
      }
    } catch (error) {
      console.warn(
        '[AgiesAI Sentinel] Could not record incident action:',
        error
      );
    }
  }

  function mapContentScriptNotice(errorMessage) {
    const message = errorMessage || '';
    let noticeTitle = 'Security Engine Unavailable';
    let noticeBody =
      'Sentinel could not verify this submission. The message was NOT sent.';

    if (
      message.includes('401') ||
      message.includes('revoked') ||
      message.includes('must be paired')
    ) {
      noticeTitle = 'Extension Unpaired / Credential Revoked';
      noticeBody =
        'Extension is disconnected or credential was revoked. Pairing is required before submissions can be verified. The message was NOT sent.';
    } else if (message.includes('403') || message.includes('disabled')) {
      noticeTitle = 'Extension Access Disabled';
      noticeBody =
        'Extension or employee access has been disabled by administrator policy. The message was NOT sent.';
    }

    return {
      decision: 'BLOCK',
      title: noticeTitle,
      body: noticeBody,
    };
  }

  function submitAfterDecision(editor, adapter = activeAdapter, approvedText = null) {
    const currentAdapter = adapter || activeAdapter || ChatGPTAdapter;
    const currentText = currentAdapter
      ? currentAdapter.readText(editor)
      : readText(editor);

    if (!currentText) {
      clearApproval();
      return false;
    }

    // Verify editor text has not been modified between policy decision and submission dispatch
    if (approvedText !== null && currentText !== approvedText) {
      clearApproval();
      console.warn(
        '[AgiesAI Sentinel] Submission text does not match approved text. Aborting submission.'
      );
      showNotice(
        'WARN',
        'Submission Modified',
        'The prompt content was modified after security evaluation. Please submit again to re-verify.'
      );
      return false;
    }

    armApprovedSubmit(currentText);

    let triggered = false;
    STATE.isProgrammaticSubmitting = true;

    try {
      if (
        currentAdapter &&
        typeof currentAdapter.submitAfterDecision === 'function'
      ) {
        triggered = Boolean(currentAdapter.submitAfterDecision(editor));
      } else {
        const button = findSubmitButton(editor);
        if (button && typeof button.click === 'function') {
          button.click();
          triggered = true;
        } else {
          const form = editor?.closest?.('form');
          if (form?.requestSubmit) {
            form.requestSubmit();
            triggered = true;
          }
        }
      }
    } catch (error) {
      console.error(
        '[AgiesAI Sentinel] Failed to trigger programmatic submission:',
        error
      );
      triggered = false;
    } finally {
      STATE.isProgrammaticSubmitting = false;
      // Immediately clear the approval token so no dangling window is left open,
      // whether programmatic submission succeeded, failed, or threw an exception.
      clearApproval();
    }

    return triggered;
  }

  async function inspectAndDecide(event, editor, adapter = activeAdapter) {
    if (STATE.busy || STATE.isProgrammaticSubmitting) {
      return;
    }

    const currentAdapter = adapter || activeAdapter || ChatGPTAdapter;
    const text = currentAdapter.readText(editor);

    if (!text) {
      return;
    }

    /*
     * CRITICAL:
     * Stop the original platform submission BEFORE contacting backend.
     */
    event.preventDefault();
    event.stopPropagation();

    if (typeof event.stopImmediatePropagation === 'function') {
      event.stopImmediatePropagation();
    }

    STATE.busy = true;

    const localFindings = localScan(text);

    showNotice(
      'WARN',
      'Scanning',
      localFindings.length
        ? `Local pre-check matched: ${localFindings.join(', ')}. Checking Sentinel policy before submission.`
        : 'Checking Sentinel policy before submission.'
    );

    try {
      const platformName = currentAdapter?.name || 'ChatGPT';

      const response = await chrome.runtime.sendMessage({
        type: API_MESSAGE,
        text,
        platform: platformName,
      });

      if (!response?.ok) {
        throw new Error(
          response?.error || 'Security engine unavailable'
        );
      }

      const result = response.result;
      const decision = result?.policy?.decision;
      const score = result?.risk?.score ?? '—';
      const incidentId = result?.incident_id;

      console.log('[AgiesAI Sentinel] Platform:', platformName);
      console.log('[AgiesAI Sentinel] Decision:', decision);
      console.log('[AgiesAI Sentinel] Risk:', result?.risk);
      console.log('[AgiesAI Sentinel] Policy:', result?.policy);

      /*
       * =========================
       * BLOCK
       * =========================
       */
      if (decision === 'BLOCK') {
        clearApproval();
        showNotice(
          'BLOCK',
          'Submission Blocked',
          `Risk ${score}/100. ${result.policy?.message || 'Blocked by policy.'}${
            incidentId ? ` Incident: ${incidentId}` : ''
          }`
        );
        return;
      }

      /*
       * =========================
       * WARN
       * =========================
       */
      if (decision === 'WARN') {
        clearApproval();
        showNotice(
          'WARN',
          'Review Required',
          `Risk ${score}/100. ${result.policy?.message || 'Review required.'}`,
          [
            {
              label: 'Cancel',
              onClick: async () => {
                clearApproval();
                await recordIncidentAction(
                  incidentId,
                  'WARNING_CANCELLED'
                );
              },
            },
            {
              label: 'Continue Anyway',
              onClick: async () => {
                await recordIncidentAction(
                  incidentId,
                  'CONTINUE_ANYWAY'
                );
                submitAfterDecision(editor, currentAdapter, text);
              },
            },
          ]
        );
        return;
      }

      /*
       * =========================
       * ALLOW
       * =========================
       */
      if (decision === 'ALLOW') {
        showNotice(
          'ALLOW',
          'Submission Allowed',
          `Risk ${score}/100. Content passed Sentinel policy.`
        );

        submitAfterDecision(editor, currentAdapter, text);
        return;
      }

      throw new Error(`Invalid policy decision: ${decision}`);
    } catch (error) {
      clearApproval();
      console.error(
        '[AgiesAI Sentinel] Security engine error:',
        error?.message || error
      );

      const notice = mapContentScriptNotice(error?.message || '');
      showNotice(
        notice.decision,
        notice.title,
        notice.body
      );
    } finally {
      STATE.busy = false;
    }
  }

  function handleSubmitEvent(event) {
    const adapter = activeAdapter || ChatGPTAdapter;
    const editor = adapter.findEditor();
    const currentText = editor ? adapter.readText(editor) : '';

    if (consumeAllowedSubmit(currentText)) {
      return;
    }

    if (editor) {
      inspectAndDecide(event, editor, adapter);
    }
  }

  function handleClick(event) {
    if (STATE.busy || STATE.isProgrammaticSubmitting) {
      return;
    }

    const adapter = activeAdapter || ChatGPTAdapter;
    const target = elementFromEvent(event);
    const button = target?.closest?.('button');

    if (!adapter.isSendButton(button)) {
      return;
    }

    const editor = adapter.findEditor();
    if (!editor) {
      return;
    }

    const currentText = adapter.readText(editor);
    if (consumeAllowedSubmit(currentText)) {
      return;
    }

    inspectAndDecide(event, editor, adapter);
  }

  function handlePointerDown(event) {
    if (STATE.busy || STATE.isProgrammaticSubmitting) {
      return;
    }

    const adapter = activeAdapter || ChatGPTAdapter;
    const target = elementFromEvent(event);
    const button = target?.closest?.('button');

    if (!adapter.isSendButton(button)) {
      return;
    }

    const editor = adapter.findEditor();
    if (!editor) {
      return;
    }

    const currentText = adapter.readText(editor);
    // If an approved token is armed for this exact text, allow pointerdown to proceed
    // so the subsequent click/submit event can consume the token.
    if (STATE.approvedToken && currentText === STATE.approvedToken.text) {
      return;
    }

    inspectAndDecide(event, editor, adapter);
  }

  function handleKeydown(event) {
    if (STATE.busy || STATE.isProgrammaticSubmitting) {
      return;
    }

    const adapter = activeAdapter || ChatGPTAdapter;
    const editor = adapter.findEditor();

    if (!editor) {
      return;
    }

    if (!adapter.isSubmitKey(event, editor)) {
      return;
    }

    const currentText = adapter.readText(editor);
    if (consumeAllowedSubmit(currentText)) {
      return;
    }

    inspectAndDecide(event, editor, adapter);
  }

  /*
   * =========================================================================
   * Hostname Validation & Event Registration
   * =========================================================================
   */
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    const hostname = window.location?.hostname || '';
    activeAdapter = resolvePlatformAdapter(hostname);

    if (!activeAdapter) {
      console.warn(
        `[AgiesAI Sentinel] Hostname "${hostname}" is not supported by any registered platform adapter.`
      );
    } else {
      /*
       * Capture phase:
       * Sentinel intercepts the event before host page event handlers.
       */
      document.addEventListener('submit', handleSubmitEvent, true);
      document.addEventListener('pointerdown', handlePointerDown, true);
      document.addEventListener('mousedown', handlePointerDown, true);
      document.addEventListener('click', handleClick, true);
      document.addEventListener('keydown', handleKeydown, true);

      if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(() => {
          if (!document.getElementById('agies-sentinel-status')) {
            const status = document.createElement('div');
            status.id = 'agies-sentinel-status';
            status.textContent = 'Sentinel active';

            status.style.cssText = [
              'position:fixed',
              'left:12px',
              'bottom:12px',
              'z-index:2147483647',
              'padding:4px 8px',
              'border-radius:6px',
              'background:#0b1220',
              'color:#86efac',
              'font:10px Inter,Arial,sans-serif',
              'opacity:.65',
              'pointer-events:none',
            ].join(';');

            document.documentElement.appendChild(status);
          }
        });

        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
        });
      }

      console.log(
        `[AgiesAI Sentinel] ${activeAdapter.name} protection active — pre-submit interception enabled.`
      );
    }
  }

  /*
   * Export adapter foundation for automated test environments
   */
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      STATE,
      API_MESSAGE,
      LOCAL_RULES,
      visible,
      elementFromEvent,
      ChatGPTAdapter,
      GeminiAdapter,
      ClaudeAdapter,
      PerplexityAdapter,
      ADAPTER_REGISTRY,
      resolvePlatformAdapter,
      findEditor,
      readText,
      isSendButton,
      findSubmitButton,
      localScan,
      clearApproval,
      armApprovedSubmit,
      consumeAllowedSubmit,
      submitAfterDecision,
      mapContentScriptNotice,
      inspectAndDecide,
      handleSubmitEvent,
      handleClick,
      handlePointerDown,
      handleKeydown,
      getActiveAdapter: () => activeAdapter,
      setActiveAdapter: (adapter) => {
        activeAdapter = adapter;
      },
    };
  }
})();