const API_BASE = 'https://agiesai-sentinel-unified.onrender.com';

async function pairExtension(code) {
  if (typeof code !== 'string') {
    throw new Error('Enter the pairing code');
  }

  const trimmedCode = code.trim();
  if (!trimmedCode) {
    throw new Error('Enter the pairing code');
  }

  const response = await fetch(`${API_BASE}/api/extension/pair`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ code: trimmedCode })
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(
      `Backend returned HTTP ${response.status}${errorText ? `: ${errorText.slice(0, 100)}` : ''}`
    );
  }

  const data = await response.json();

  if (
    !data?.credential ||
    !data?.employee_id ||
    typeof data.credential !== 'string' ||
    !data.credential.trim() ||
    typeof data.employee_id !== 'string' ||
    !data.employee_id.trim()
  ) {
    throw new Error(
      'Pairing response must contain a non-empty credential and employee_id'
    );
  }

  const credential = data.credential;
  const employeeId = data.employee_id;
  const employeeName = data.employee_name || data.employeeName || data.name || '';

  await chrome.storage.local.set({
    credential,
    employeeId,
    employeeName,
    connectionStatus: 'CONNECTED',
    connectionError: null,
    revokedAt: null
  });

  return {
    employeeId,
    employeeName
  };
}

async function handleAuthenticatedResponse(response, activeCredential) {
  if (response.status === 401) {
    // Credential is invalid or revoked.
    // Ensure cleanup does not erase a newly paired credential due to a race between requests:
    const current = await chrome.storage.local.get({ credential: null });
    if (current.credential && current.credential === activeCredential) {
      await chrome.storage.local.remove('credential');
      await chrome.storage.local.set({
        connectionStatus: 'REVOKED',
        connectionError: 'Extension credential revoked or invalid (HTTP 401)',
        revokedAt: new Date().toISOString()
      });
    }
    throw new Error('Extension credential revoked or invalid (HTTP 401)');
  }

  if (response.status === 403) {
    // 403 indicates employee or extension access is disabled.
    // Do NOT automatically classify as credential revocation; preserve stored credential.
    await chrome.storage.local.set({
      connectionStatus: 'DISABLED',
      connectionError: 'Extension access disabled by administrator (HTTP 403)'
    });
    throw new Error('Extension access disabled by administrator (HTTP 403)');
  }

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(
      `Backend returned HTTP ${response.status}${errorText ? `: ${errorText.slice(0, 100)}` : ''}`
    );
  }

  return response.json();
}

const SUPPORTED_PLATFORMS = new Set([
  'ChatGPT',
  'Gemini',
  'Claude',
  'Copilot',
  'Perplexity',
  'DeepSeek',
  'Grok',
]);

function validatePlatform(platform) {
  if (typeof platform === 'string' && SUPPORTED_PLATFORMS.has(platform)) {
    return platform;
  }
  return 'ChatGPT';
}

async function analyze(text, platform = 'ChatGPT') {
  const validatedPlatform = validatePlatform(platform);
  const { credential, employeeId } = await chrome.storage.local.get({
    credential: null,
    employeeId: null
  });

  if (!credential) {
    await chrome.storage.local.set({
      connectionStatus: 'UNPAIRED',
      connectionError: 'Extension must be paired first'
    });
    throw new Error('Extension must be paired first');
  }

  const response = await fetch(`${API_BASE}/api/detect`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${credential}`
    },
    body: JSON.stringify({
      text,
      employee_id: employeeId,
      platform: validatedPlatform
    })
  });

  return handleAuthenticatedResponse(response, credential);
}

function isAuthorizedPopupSender(sender) {
  if (!sender || typeof sender !== 'object') {
    return false;
  }

  // Reject content scripts: content scripts always send with sender.tab populated
  if (sender.tab) {
    return false;
  }

  // Sender must have an extension ID matching our extension runtime
  const extensionId = typeof chrome !== 'undefined' && chrome?.runtime?.id ? chrome.runtime.id : null;
  if (extensionId) {
    if (!sender.id || sender.id !== extensionId) {
      return false;
    }
  } else if (!sender.id) {
    return false;
  }

  // Sender URL must match the exact popup.html URL
  const expectedPopupUrl = typeof chrome !== 'undefined' && chrome?.runtime?.getURL
    ? chrome.runtime.getURL('popup.html')
    : (sender.id ? `chrome-extension://${sender.id}/popup.html` : null);

  if (!expectedPopupUrl || typeof sender.url !== 'string') {
    return false;
  }

  if (sender.url !== expectedPopupUrl) {
    return false;
  }

  return true;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'AGIES_RECORD_ACTION') {
    recordIncidentAction(message.incidentId, message.action)
      .then((result) => {
        sendResponse({
          ok: true,
          result
        });
      })
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error.message
        });
      });

    return true;
  }

  if (message?.type === 'AGIES_PAIR_EXTENSION') {
    if (!isAuthorizedPopupSender(sender)) {
      sendResponse({
        ok: false,
        error: 'Unauthorized pairing sender: pairing requests must originate from the extension popup.'
      });
      return false;
    }

    pairExtension(message.code)
      .then(({ employeeId, employeeName }) => {
        sendResponse({
          ok: true,
          employeeId,
          employeeName
        });
      })
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error.message
        });
      });

    return true;
  }

  if (message?.type !== 'AGIES_ANALYZE') {
    return;
  }

  const platform = validatePlatform(message?.platform);

  analyze(message.text, platform)
    .then(async (result) => {
      await chrome.storage.local.set({
        lastResult: {
          ...result,
          platform: result?.platform || platform,
          checkedAt: new Date().toISOString()
        }
      });

      sendResponse({
        ok: true,
        result
      });
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        error: error.message
      });
    });

  return true;
});

async function recordIncidentAction(incidentId, action) {
  if (!incidentId) {
    throw new Error('Missing incident ID');
  }

  const { credential } = await chrome.storage.local.get({
    credential: null
  });

  if (!credential) {
    throw new Error('Extension must be paired first');
  }

  const response = await fetch(
    `${API_BASE}/api/incidents/${encodeURIComponent(incidentId)}/action`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${credential}`
      },
      body: JSON.stringify({ action })
    }
  );

  return handleAuthenticatedResponse(response, credential);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    API_BASE,
    SUPPORTED_PLATFORMS,
    validatePlatform,
    pairExtension,
    handleAuthenticatedResponse,
    analyze,
    recordIncidentAction,
    isAuthorizedPopupSender,
  };
}
