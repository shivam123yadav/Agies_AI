const API_BASE = 'https://agiesai-sentinel-unified.onrender.com';

async function updateConnectionStatus() {
  const card = document.getElementById('connectionStatusCard');
  const text = document.getElementById('connectionStatusText');
  const pairingStatus = document.getElementById('pairingStatus');

  if (!card || !text) return;

  const data = await chrome.storage.local.get({
    credential: null,
    connectionStatus: null,
    employeeName: '',
    employeeId: ''
  });

  const { credential, connectionStatus, employeeName, employeeId } = data;

  if (!credential) {
    card.className = 'status disconnected';
    if (connectionStatus === 'REVOKED') {
      text.textContent = 'Disconnected — Revoked';
      if (pairingStatus && !pairingStatus.textContent) {
        pairingStatus.textContent = 'Extension credential revoked by administrator. Please pair again.';
        pairingStatus.className = 'pairing-status error';
      }
    } else {
      text.textContent = 'Unpaired — Disconnected';
      if (pairingStatus && !pairingStatus.textContent) {
        pairingStatus.textContent = 'Pairing required to activate protection.';
        pairingStatus.className = 'pairing-status';
      }
    }
  } else if (connectionStatus === 'DISABLED') {
    card.className = 'status disabled';
    text.textContent = 'Access Disabled by Admin';
  } else {
    card.className = 'status';
    const label = employeeName ? `Protection Active (${employeeName})` : 'Protection Active';
    text.textContent = label;
  }
}

async function loadEmployees() {
  const select = document.getElementById('employeeSelect');
  const status = document.getElementById('identityStatus');
  try {
    const response = await fetch(`${API_BASE}/api/employees`);
    if (!response.ok) throw new Error(`Backend returned HTTP ${response.status}`);
    const data = await response.json();
    const stored = await chrome.storage.local.get({ employeeId: 'EMP-DEMO-001' });
    select.innerHTML = '';

    for (const employee of data.employees || []) {
      const option = document.createElement('option');
      option.value = employee.employee_id;
      option.textContent = `${employee.name} • ${employee.employee_id}`;
      option.disabled = employee.status !== 'Active';
      select.appendChild(option);
    }

    const valid = [...select.options].find((o) => o.value === stored.employeeId && !o.disabled);
    select.value = valid ? stored.employeeId : (select.options[0]?.value || '');
    if (select.value) {
      await chrome.storage.local.set({ employeeId: select.value });
      const employee = (data.employees || []).find((e) => e.employee_id === select.value);
      status.textContent = employee ? `${employee.department} • ${employee.role}` : 'Identity selected';
    }
  } catch (error) {
    select.innerHTML = '<option value="EMP-DEMO-001">EMP-DEMO-001</option>';
    select.value = 'EMP-DEMO-001';
    status.textContent = 'Backend unavailable - using demo identity';
  }

  select.addEventListener('change', async () => {
    await chrome.storage.local.set({ employeeId: select.value });
    status.textContent = 'Identity saved for future checks.';
  });
}

async function loadLastResult() {
  const data = await chrome.storage.local.get('lastResult');
  const last = data.lastResult;
  if (!last) return;

  const decision = last.policy?.decision || 'UNKNOWN';
  const score = last.risk?.score;
  const time = last.checkedAt ? new Date(last.checkedAt).toLocaleTimeString() : '';
  const employee = last.employee_name ? ` • ${last.employee_name}` : '';

  document.getElementById('decision').textContent = `${decision}${score != null ? ` • Risk ${score}/100` : ''}`;
  document.getElementById('details').textContent = `${last.policy?.message || 'Security decision received.'}${employee}${time ? ` Checked ${time}.` : ''}`;
}

async function load() {
  setupPairing();
  await updateConnectionStatus();
  await loadEmployees();
  await loadLastResult();

  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        updateConnectionStatus();
      }
    });
  }
}

function setupPairing() {
  const input = document.getElementById('pairingCodeInput');
  const button = document.getElementById('pairBtn');
  const status = document.getElementById('pairingStatus');

  if (!button || !input || !status) return;

  async function handlePair() {
    if (button.disabled) {
      return;
    }

    const code = input.value.trim();
    if (!code) {
      status.textContent = 'Please enter a pairing code.';
      status.className = 'pairing-status error';
      return;
    }

    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = 'Pairing…';
    status.textContent = 'Pairing extension…';
    status.className = 'pairing-status';

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'AGIES_PAIR_EXTENSION',
        code
      });

      if (response && response.ok) {
        const name = response.employeeName || 'Employee';
        const id = response.employeeId || '';
        status.textContent = `Paired successfully: ${name} (${id})`;
        status.className = 'pairing-status success';
        input.value = '';
        await updateConnectionStatus();
        await loadEmployees();
      } else {
        const errorMsg = response?.error || 'Pairing failed. Please check the code and try again.';
        status.textContent = errorMsg;
        status.className = 'pairing-status error';
        await updateConnectionStatus();
      }
    } catch (err) {
      status.textContent = err?.message || 'Error communicating with background worker.';
      status.className = 'pairing-status error';
      await updateConnectionStatus();
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  }

  button.addEventListener('click', handlePair);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      handlePair();
    }
  });
}

load();
